class Employee:

    @staticmethod
    def get_fired():
        return f"fired..."
