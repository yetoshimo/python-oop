from project.car import Car


class SportsCar(Car):

    @staticmethod
    def race():
        return "racing..."


# s = SportsCar()
# print(s.move())
# print(s.drive())
# print(s.race())
