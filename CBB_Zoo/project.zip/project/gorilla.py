from project.mammal import Mammal


class Gorilla(Mammal):

    def __init__(self, name: str):
        super(Gorilla, self).__init__(name)
