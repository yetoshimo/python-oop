class Animal:

    @staticmethod
    def eat():
        return f"eating..."
