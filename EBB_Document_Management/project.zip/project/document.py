class Document:
    def __init__(self, id: int, category_id: int, topic_id: int, file_name: str):
        self.file_name = file_name
        self.topic_id = topic_id
        self.category_id = category_id
        self.id = id
        self.tags = []

    def __repr__(self):
        return f"Document {self.id}: {self.file_name}; category {self.category_id}, topic {self.topic_id}, tags: {', '.join(self.tags)}"

    @staticmethod
    def check_tag_exists(_tag, _tags):
        return _tag in _tags

    @classmethod
    def from_instances(cls, id: int, category, topic, file_name: str):
        return cls(id, category.id, topic.id, file_name)

    def add_tag(self, tag_content: str):
        if not self.check_tag_exists(tag_content, self.tags):
            self.tags.append(tag_content)

    def remove_tag(self, tag_content: str):
        if self.check_tag_exists(tag_content, self.tags):
            self.tags.remove(tag_content)

    def edit(self, file_name: str):
        self.file_name = file_name
